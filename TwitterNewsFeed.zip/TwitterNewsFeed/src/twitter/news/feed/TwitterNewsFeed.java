/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package twitter.news.feed;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 *
 * @author Gontse Ntshegi
 */
public class TwitterNewsFeed {

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner userFile=null;//user.txt
        Scanner tweetsFile=null;//tweets.txt
        UsersList usersList=new UsersList();//create a list to contain all the users in the file
        if(args.length==-0)
        {
           System.out.println("No Arguments supplied");
        }
        else{
        int count=0;
        try
        {
            
            userFile = new Scanner(new FileInputStream(args[0]));
            tweetsFile = new Scanner(new FileInputStream(args[1]));
           
            /////////////// UserFile Analysis and Capturing///////////
            while(userFile.hasNextLine())
            {
                User users = new User();//create an object for each user
                count=0;
                StringTokenizer token =new StringTokenizer(userFile.nextLine(),", ");
                while(token.hasMoreTokens())
                {
                     String tokenStr = token.nextToken();
                   if(tokenStr.equalsIgnoreCase("follows"))
                    {
                        count++;
                    }
                     else if (count==0)//user
                    {
                        users.setUser(tokenStr);
                      
                     
                    }
                    else if(count>0)//next inline is a follower
                    {
                        users.setFollower(tokenStr);
                        //check if this follower is a user
                        if(usersList.users.contains(new User(tokenStr)))
                        {
                            //do nothing
                        } else {//add follower as user
                            User u =new User();
                            u.setUser(tokenStr);
                            usersList.addUSer(u);
                         }
                    }
                   
                }
                 usersList.addUSer(users);
                 
            }
            
            {
            
         /////////// TweetsFile Analysis and Capturing /////////////////////////
           ArrayList<String> queue = new ArrayList<>();
          while(tweetsFile.hasNextLine())
          {
              String str = tweetsFile.nextLine();
              int usernameIndex = str.indexOf(">");
              String username  = str.substring(0,usernameIndex);
              
              String message = str.substring(usernameIndex+2,str.length());
              queue.add(message);
             
              int index=usersList.findUsername(username);//find the user in the userlist and return its index
              if(index>-1){
              usersList.users.get(index).tweets.setTweets(message);
              }
             
          }
           display(usersList,queue);
            }
        }
        catch(IOException e)
        {
            System.out.println(e.getMessage());
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
     }
    }
    
    public static void display(UsersList userlist,ArrayList q)
    {
        Object[] start = q.toArray();
        userlist.sortList();//sort the list in alphabetical order
        for(int i=0;i<userlist.users.size();i++)
        {
            ArrayList<User> following = checkSuccessiveTweets(userlist,i); //store all followers this user is following          
            following.add(userlist.users.get(i));//now add this user in the following list (because he also follows himself
            String username=userlist.users.get(i).username;
            System.out.println(username);//print out this user
          for(int x=0;x<start.length;x++)   
          {
          for(User s: following)
           {
            for(int j=0;j<s.tweets.tweets.size();j++)
            {
             
              if(s.tweets.tweets.get(j).equals(start[x]+""))//prints the tweets in order
               {
                    String tweet = s.tweets.tweets.get(j);
                    String username2 =s.username;
                    System.out.println("\t@"+username2+":"+tweet);
                    
               }
            }
           }
          }
            
        }
      
    }
    //get the total number of user each user is following
    public static ArrayList<User> checkSuccessiveTweets(UsersList userlist,int index)
    {
       
           ArrayList<Followers> following= userlist.users.get(index).getFollowers();
           ArrayList<User> temp = new ArrayList<>();//temporary object to store the followers
         
                for(int j=0;j<following.size();j++)
                {
                    for(int x=0;x<userlist.users.size();x++)//get followers
                    {
                       if(following.get(j).username.equalsIgnoreCase(userlist.users.get(x).username))
                       {
                        temp.add(userlist.users.get(x));
                       }
                    }
                }
          return temp;
        
        
    }
    
}
