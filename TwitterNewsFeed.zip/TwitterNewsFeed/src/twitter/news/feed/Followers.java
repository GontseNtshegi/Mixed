/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package twitter.news.feed;

/**
 * A class that differentiate between users and followers
 * @author Gontse Ntshegi
 */
public class Followers extends User{
  

    public Followers() 
    {
    }
    public Followers(String f)
    {
        super(f);
    }
    
}
