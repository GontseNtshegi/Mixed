/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package twitter.news.feed;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 *
 * @author Gontse Ntshegi
 */
public class User{
    //intance variables
    public String username;
    public ArrayList<Followers> followers;
    public Tweet tweets;
    
    public User()//default constructor
    {
        this.followers = new ArrayList<>();
        this.tweets =new Tweet();
    }
  public User(String usr)//parameterised constructor
  {
      this.username = usr;
  }
    public String getUser() {
        return username;
    }

    public void setUser(String user) {
        this.username = user;
    }

    public ArrayList<Followers> getFollowers() {
        return followers;
    }
   public ArrayList<String> getStringFollowers()//get followers as string to making sorting easy and remove duplicates
   {
       ArrayList<String> temp = new ArrayList<>();
       
       for(Followers f:this.followers)
       {
           temp.add(f.username);
       }
       
       return temp;
   }
    public void setFollower(String followers) {
        User following =new Followers();
        following.username=followers;
        
        if(this.followers.isEmpty()){
        this.followers.add((Followers) following);
        }
        else
        {
            for(int i=0;i<this.followers.size();i++)
            {
                if(!this.followers.get(i).username.equalsIgnoreCase(followers))
                {
                    this.followers.add((Followers) following);
                    i=this.followers.size();
                }
            }
        }
    }
   
    @Override
  public String toString()
  {
      String temp="";
        
        for(int i=0;i<followers.size();i++)
        {
            temp=temp+" "+followers.get(i).username;
        }
      return (username+" FOLLOWS "+temp);
  }
 
  public void removeFollowers()
  {
      followers.removeAll(followers);
  }
  public void setFollowers(Set<String> set)
  {
      removeFollowers();
      ArrayList<Followers> list = new ArrayList<>();
      for(String l:set)
      {
          list.add(new Followers(l));
      }
      
      this.followers=list;
  }
    
}
