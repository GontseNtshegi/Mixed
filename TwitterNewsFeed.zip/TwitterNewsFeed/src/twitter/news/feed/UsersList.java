/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package twitter.news.feed;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

/**
 *This class stores stores all users together with their followers in a list
 * @author Gontse Ntshegi
 */
public class UsersList {
    public ArrayList<User> users;
    
    public UsersList()//default constructor
    {
        users = new ArrayList<>();
    }
    public void addUSer(User user)//add user in the list
    {
        if(this.users.isEmpty())//nothing in the list
        {
            this.users.add(user);//add this user in the list
        }
        else
        {
        for(int i=0;i<this.users.size();i++)//check for duplicates
        {
            if(!this.users.get(i).username.equalsIgnoreCase(user.username) && i==this.users.size()-1)//check if the user exists
            {
             
                this.users.add(user);//add this user in the list
                
            }
            else if(this.users.get(i).username.equalsIgnoreCase(user.username))//if user equals another user in the list
            {
               
                ArrayList<String> s1 = new ArrayList<>();
                s1.addAll(user.getStringFollowers());
                
                ArrayList<String> s2 = new ArrayList<>();
                s2.addAll(this.users.get(i).getStringFollowers());
                /////// merger all the followers together because its the same user and remove duplicates
                Set<String> set = new HashSet<>(s1);
                set.addAll(s2);
                this.users.get(i).setFollowers(set);
                i=this.users.size();//exit the loop
            }
            
        }
        }
    }
    public int findUsername(String username)//find user in the list
    {
        int index=-1;
        for(int i=0;i<users.size();i++)
        {
            if(users.get(i).getUser().equalsIgnoreCase(username))
            {             
                return i;
            }
        }
        return index;
    }
    public void sortList()//sort the list of users using their username
            {
                 Collections.sort(this.users,new Comparator()
                 {
                     @Override
                     public int compare(Object t, Object t1) {
                        
                       String str1=((User)t).username;
                       String str2=((User)t1).username;
                        return str1.compareTo(str2);
                     }
                     
                 });
            }
    @Override
    public String toString()//to string
    {
        String temp="";
        for(User x:users)
        {
            temp =temp+" "+x+'\n';
        }
        return temp;
    }
    
}
